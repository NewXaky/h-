A highly convenient mod for generating resources when a unit is killed.

<img width="500" height="500" alt="icon" src="https://github.com/user-attachments/assets/dcab5784-34ef-4fcc-a53f-c043d33680fc" />

---

Supports solo and co-op play; settings are configured by the host and automatically applied during gameplay. There's a convenient button in the top left corner for this in-game feature. 
(The settings are also in the main menu)

<img width="447" height="140" alt="image" src="https://github.com/user-attachments/assets/4ee950b9-7d79-44ca-a1b6-7b80ac3baef1" /> <img width="253" height="112" alt="image" src="https://github.com/user-attachments/assets/2407ca47-a323-4d2a-9756-449b2999f1fb" />



Supports any modded items, with full customization options:

<img width="838" height="767" alt="image" src="https://github.com/user-attachments/assets/bef3dc78-cedb-4b10-aeb5-b6cadbec2a40" />


Allows you to set multipliers, which will help you change resource amounts quickly and more precisely. You can set crazy numbers like 999 :D

<img width="684" height="483" alt="image" src="https://github.com/user-attachments/assets/a8f61bc5-79d8-4527-8695-fb65ac7404ba" />


Resource drops are visually appealing. A text message indicating the quantity and icon of the item appears at the location of death:

<img width="936" height="611" alt="image" src="https://github.com/user-attachments/assets/7bc0fc64-a2ca-4d18-b092-03b24da0b9f9" />


You can turn off resource drops or display resource drops (leaving the bonus for kills):

<img width="422" height="137" alt="image" src="https://github.com/user-attachments/assets/aa950fbd-78c7-48a9-9a92-235c88712eb2" />


The button can be moved to any convenient position. If for some reason the button moves off the screen, it can be reset:

<img width="516" height="193" alt="image" src="https://github.com/user-attachments/assets/f40b13ef-af22-4711-8664-bcd294de6187" /> <img width="284" height="54" alt="image" src="https://github.com/user-attachments/assets/8157dab7-df02-4d9e-9bb4-32d10e824bdb" />

This mod can completely change the gameplay on PvP maps or campaign sectors.

---

Discord: 25frame.mp4

